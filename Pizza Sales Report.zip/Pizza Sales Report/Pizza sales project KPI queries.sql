select * from dbo.pizza_sales

-- total revenue

select SUM(dbo.pizza_sales.total_price) as total_revenue from dbo.pizza_sales;

-- average order value

select (SUM(dbo.pizza_sales.total_price) / COUNT(DISTINCT order_id)) as average_order_value from dbo.pizza_sales;

-- total pizzas sold

select SUM(dbo.pizza_sales.quantity) as total_pizzas_sold from dbo.pizza_sales;

-- total orders

select COUNT(DISTINCT(dbo.pizza_sales.order_date)) as total_orders from dbo.pizza_sales;

-- Average pizzas per order

select CAST ((SUM(dbo.pizza_sales.quantity) / COUNT(DISTINCT(dbo.pizza_sales.order_id) )) as decimal(10,2)) as average_pizza_per_order from dbo.pizza_sales;

-- Daily trends for  our orders

select DATENAME(DW, dbo.pizza_sales.order_date) as day_week , COUNT(DISTINCT(dbo.pizza_sales.order_id)) as total_orders_daywise
from dbo.pizza_sales
group by DATENAME(DW, dbo.pizza_sales.order_date);

-- Monthly trends for orders

select DATENAME(MONTH, dbo.pizza_sales.order_date) as month_name , COUNT(DISTINCT(dbo.pizza_sales.order_id)) as total_orders_monthwise
from dbo.pizza_sales
group by DATENAME(MONTH, dbo.pizza_sales.order_date)
order by total_orders_monthwise desc;

-- Percentage of sales by pizza category

select DISTINCT(dbo.pizza_sales.pizza_category) as pizza_category , sum(dbo.pizza_sales.total_price) as category_price , CAST((sum(dbo.pizza_sales.total_price)*100)/(Select SUM(dbo.pizza_sales.total_price) as percentage_price_category_wise from dbo.pizza_sales) AS decimal(10,2))
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_category;

-- percentage of sales by pizza size

select DISTINCT(dbo.pizza_sales.pizza_size) as pizza_size , sum(dbo.pizza_sales.total_price) as size_price , CAST((sum(dbo.pizza_sales.total_price)*100)/(Select SUM(dbo.pizza_sales.total_price) as percentage_price_size_wise from dbo.pizza_sales) AS decimal(10,2))
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_size;

-- total pizza sold by pizza category

select DISTINCT(dbo.pizza_sales.pizza_category) as pizza_category ,  sum(dbo.pizza_sales.quantity) as pizza_count
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_category;

-- Top 5 best sellers by revenue, total quantity and total orders

select top 5 

(dbo.pizza_sales.pizza_name) AS pizza_name, sum(dbo.pizza_sales.total_price) as pizza_count_revenue
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_name
order by pizza_count_revenue desc;

select top 5 

(dbo.pizza_sales.pizza_name) AS pizza_name, sum(dbo.pizza_sales.quantity) as pizza_count_quantity
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_name
order by pizza_count_quantity desc;

select top 5 

(dbo.pizza_sales.pizza_name) AS pizza_name, count(distinct(dbo.pizza_sales.order_id)) as pizza_count_orders
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_name
order by pizza_count_orders desc;

-- bottom 5 best sellers by revenuw, total quantity, total order


select top 5 

(dbo.pizza_sales.pizza_name) AS pizza_name, sum(dbo.pizza_sales.total_price) as pizza_count_revenue
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_name
order by pizza_count_revenue asc;

select top 5 

(dbo.pizza_sales.pizza_name) AS pizza_name, sum(dbo.pizza_sales.quantity) as pizza_count_quantity
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_name
order by pizza_count_quantity asc;

select top 5 

(dbo.pizza_sales.pizza_name) AS pizza_name, count(distinct(dbo.pizza_sales.order_id)) as pizza_count_orders
from dbo.pizza_sales
group by dbo.pizza_sales.pizza_name
order by pizza_count_orders asc;








 


