select * from dbo.['Human Resources$'];



