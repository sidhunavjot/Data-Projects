select * from dbo.order_details$
select * from dbo.orders$
select * from dbo.pizza_types$
select * from dbo.pizzas$

--Retrieve the total number of orders placed.

select count( distinct order_id ) as total_orders from order_details$;

--Calculate the total revenue generated from pizza sales.


select
	round(sum( p.price * od.quantity),2) as total_amount_per_orderid
	from dbo.pizzas$ p
	full outer join dbo.order_details$ od 
		on p.pizza_id = od.pizza_id;

--Identify the highest-priced pizza.

select top 1
name, price
from dbo.pizza_types$ pt
full outer join dbo.pizzas$ p
on pt.pizza_type_id = p.pizza_type_id
order by price desc ;

--Identify the most common pizza size ordered.

select top 1 
size, sum(quantity) as total_orders_of_pizza_size
from dbo.pizzas$
full outer join dbo.order_details$
on dbo.pizzas$.pizza_id = dbo.order_details$.pizza_id
group by size
order by total_orders_of_pizza_size desc;

--List the top 5 most ordered pizza types along with their quantities.

select top 5

name, count(name) as Pizza_Type_Name
from(( 

select 
dbo.pizza_types$.pizza_type_id, name, dbo.pizzas$.pizza_id
from dbo.pizza_types$
full outer join  dbo.pizzas$
on dbo.pizza_types$.pizza_type_id = dbo.pizzas$.pizza_type_id ) as Table1

full outer join dbo.order_details$
on Table1.pizza_id = dbo.order_details$.pizza_id)
group by name
order by Pizza_Type_Name desc


--Join the necessary tables to find the total quantity of each pizza category ordered.

select
category, sum(quantity) as quant_pizza_category
from(
select 
dbo.pizza_types$.category, dbo.pizzas$.pizza_id
from dbo.pizza_types$
full outer join dbo.pizzas$
on dbo.pizza_types$.pizza_type_id = dbo.pizzas$.pizza_type_id) as tb1
full outer join dbo.order_details$
on tb1.pizza_id = dbo.order_details$.pizza_id
group by category

--Determine the distribution of orders by hour of the day.

select 
DATEPART(hour, dbo.orders$.time) as hour_of_day, count(order_id)
from dbo.orders$
group by DATEPART(hour, dbo.orders$.time)
order by DATEPART(hour, dbo.orders$.time)

--Join relevant tables to find the category-wise distribution of pizzas.

select
category,sum(quantity) as total_distribution
from(
select
category, pizza_id
from dbo.pizza_types$
full outer join dbo.pizzas$
on dbo.pizza_types$.pizza_type_id = dbo.pizzas$.pizza_type_id)  as tbl1
full outer join dbo.order_details$
on tbl1.pizza_id = dbo.order_details$.pizza_id
group by category

--Group the orders by date and calculate the average number of pizzas ordered per day.

select
date, round(avg(quantity),2)  as avg_pizzas
from dbo.orders$
full outer join dbo.order_details$
on dbo.orders$.order_id = dbo.order_details$.order_id
group by date

--Determine the top 3 most ordered pizza types based on revenue.

select top 3
name, sum(quantity) as total_pizza
from
(select
name, pizza_id
from dbo.pizza_types$
full outer join dbo.pizzas$
on dbo.pizza_types$.pizza_type_id = dbo.pizzas$.pizza_type_id) as tab1
full outer join dbo.order_details$
on  tab1.pizza_id = dbo.order_details$.pizza_id
group by name
order by total_pizza desc;

--Calculate the percentage contribution of each pizza type to total revenue.

with perc as (
select 
name, round(sum (price*quantity),2) as amount
from (
select
pizza_type_id, price, quantity
from dbo.order_details$
full outer join dbo.pizzas$
on dbo.order_details$.pizza_id = dbo.pizzas$.pizza_id) as tabu1
full outer join dbo.pizza_types$
on tabu1.pizza_type_id = dbo.pizza_types$.pizza_type_id
group by name)

select 
name, amount, round((amount*100.0)/sum(amount) over(),2) as percentage
from perc
order by percentage desc













