use [HR DATA]
select * from HR_data;

-- 1) The sum of total employyees from HR Dashboard

select COUNT(HR_data.[emp no])from HR_data
where HR_data.[CF_current Employee] =1;

-- 2) The sum of total attribution from HR dashboard

select count(HR_data.Attrition) from HR_data
where HR_data.Attrition = 'Yes';

-- 3) Attribution Rate : The sum of total employyees by division by total attribution from HR Dashboard

WITH cte AS (
    SELECT 
        CAST(
            (SELECT COUNT([emp no]) 
             FROM HR_data 
             WHERE [CF_current Employee] = 1) AS FLOAT
        ) / 
        CAST(
            (SELECT COUNT(Attrition) 
             FROM HR_data 
             WHERE Attrition = 'Yes') AS FLOAT
        ) AS Ratio
)
SELECT * FROM cte;

-- 4) Active Employees : The sum of total employees by substraction by total attribution from HR dashboard


WITH cteA AS (
    SELECT 
        CAST(
            (SELECT COUNT([emp no]) 
             FROM HR_data 
             WHERE [CF_current Employee] = 1) AS FLOAT
        ) -
        CAST(
            (SELECT COUNT(Attrition) 
             FROM HR_data 
             WHERE Attrition = 'Yes') AS FLOAT
        ) AS Difference
)

SELECT * FROM cteA;

-- 5) Average Age : The average age from HR dashboard

select AVG(HR_data.Age) from HR_data;

-- 6) Attribution count by department  : Create pie chart display the attribution  count by department from hr dashboard

select HR_data.Department, COUNT(HR_data.Attrition) as Attribution_Count from HR_data
where HR_data.Attrition = 'Yes'
group by HR_data.Department;

-- 7) Job Role by rate by total employee: Create table to find the job role by rate by total employee

select HR_data.[Job Role], count (HR_data.[emp no]) as total_employees
from HR_data
where HR_data.[CF_current Employee] = 1
GROUP  BY HR_data.[Job Role];

-- 8) Total employee by education : Create a stacked columns chart find the total employee by education from hr dashboard

select HR_data.Education, COUNT(HR_data.[emp no]) as emp_count 
from HR_data
where HR_data.[CF_current Employee] = 1
group by HR_data.Education;

-- 9) Total Employee by Age Group : Create stacked columns chart. find the total employee by age group from HR Dashboard

select HR_data.[CF_age band], COUNT(HR_data.[emp no]) as emp_count 
from HR_data
where HR_data.[CF_current Employee] = 1
group by HR_data.[CF_age band];

-- 10) Job role by month income by gender : Create a line clustered chart, find the job role by month income by gender

select HR_data.[Job Role], Gender, sum([Monthly Income]) as salary_total 
from HR_data
group by HR_data.[Job Role], Gender;

