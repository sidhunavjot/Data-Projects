select * from dbo.hrdata;

-- data cleaning and preprocessing

SET sql_safe_updates = 0;

UPDATE dbo.hrdata
SET birthdate = CASE
		WHEN birthdate LIKE '%/%' THEN date_format(str_to_date(birthdate,'%m/%d/%Y'),'%Y-%m-%d')
        WHEN birthdate LIKE '%-%' THEN date_format(str_to_date(birthdate,'%m-%d-%Y'),'%Y-%m-%d')
        ELSE NULL
		END;
	
ALTER TABLE hr
MODIFY COLUMN birthdate DATE; 