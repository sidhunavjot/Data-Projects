select * from dbo.Worksheet
select * from dbo.invoice
select * from dbo.album
select * from dbo.album2
select * from dbo.artist
select * from dbo.customer
select * from dbo.employee
select * from dbo.genre
select * from dbo.invoice_line
select * from dbo.media_type
select * from dbo.playlist_track
select * from dbo.track

-- Who is the senior most employee based on job title? 


SELECT top 1
title, last_name, first_name 
FROM employee
ORDER BY levels DESC

--Which countries have the most Invoices? 


select top 1
billing_country, COUNT(billing_country) as invoice_count
from dbo.invoice
group by billing_country
order by invoice_count 

--What are top 3 values of total invoice? 

select top 3
total
from dbo.invoice
group by total
order by total desc

--Which city has the best customers? We would like to throw a promotional Music Festival in the city we made the most money. 
--Write a query that returns one city that has the highest sum of invoice totals. 
--Return both the city name & sum of all invoice totals

select top 1
billing_city, sum(total)as invoice_total
from invoice
group by billing_city
order by invoice_total desc

--Who is the best customer? The customer who has spent the most money will be declared the best customer. 
--Write a query that returns the person who has spent the most money



select top 1
first_name, last_name, sum(total) as amount_spent
from customer
full outer join invoice
on customer.customer_id = invoice.customer_id
group by first_name, last_name
order by amount_spent desc;

-- Write query to return the email, first name, last name, & Genre of all Rock Music listeners. 
-- Return your list ordered alphabetically by email starting with A

-- METHOD 1

with main_table as (select distinct
name, first_name, last_name, email
from(
select
name, customer_id
from(
select
name, invoice_id
from(
Select 
track_id, genre.name
from dbo.genre
full outer join dbo.track
on genre.genre_id = track.genre_id) as track_name
full outer join dbo.invoice_line
on track_name.track_id = dbo.invoice_line.track_id) as name_invoice_id
full outer join dbo.invoice
on  name_invoice_id.invoice_id = dbo.invoice.invoice_id) as name_cust_id
full outer join dbo.customer
on name_cust_id.customer_id = dbo.customer.customer_id
where name = 'Rock' )

select * from main_table;


--METHOD2 

SELECT DISTINCT email AS Email,first_name AS FirstName, last_name AS LastName, genre.name AS Name
FROM customer
JOIN invoice ON invoice.customer_id = customer.customer_id
JOIN dbo.invoice_line ON dbo.invoice_line.invoice_id = invoice.invoice_id
JOIN track ON track.track_id = dbo.invoice_line.track_id
JOIN genre ON genre.genre_id = track.genre_id
WHERE genre.name LIKE 'Rock'
ORDER BY email;

-- Let's invite the artists who have written the most rock music in our dataset. 
-- Write a query that returns the Artist name and total track count of the top 10 rock bands 

select top 10
artist.name, count(artist.artist_id) as number_of_songs
from dbo.artist
join dbo.album on dbo.album.artist_id = dbo.artist.artist_id
join dbo.track on dbo.album.[ï»¿album_id] = dbo.track.album_id
join dbo.genre on dbo.track.genre_id = dbo.track.genre_id
where genre.name LIKE 'Rock'
group by artist.artist_id, artist.name
order by number_of_songs desc; 

-- Return all the track names that have a song length longer than the average song length. 
-- Return the Name and Milliseconds for each track. Order by the song length with the longest songs listed first 

select
dbo.track.name, dbo.track.milliseconds
from dbo.track
where milliseconds > (
	select 
	avg(milliseconds) as avg_track_length
	from dbo.track)
order by milliseconds desc


-- Find how much amount spent by each customer on artists? 
-- Write a query to return customer name, artist name and total spent 


select 
dbo.customer.first_name as customer_firstName, dbo.customer.last_name as customer_lastName, dbo.artist.name as artist_name, sum(quantity * dbo.invoice_line.unit_price) as product_qunt_uniprice
from dbo.customer
join dbo.invoice on dbo.customer.customer_id = dbo.invoice.customer_id
join dbo.invoice_line on dbo.invoice.invoice_id = dbo.invoice_line.invoice_id
join dbo.track on dbo.invoice_line.track_id = dbo.track.track_id
join dbo.album on dbo.track.album_id = dbo.album.[ï»¿album_id]
join dbo.artist on dbo.album.artist_id = dbo.artist.artist_id
group by dbo.customer.first_name, dbo.customer.last_name, dbo.artist.name

























 



