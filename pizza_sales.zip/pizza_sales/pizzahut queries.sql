select * from pizzahut.dbo.pizzas
select * from pizzahut.dbo.pizza_types
select * from pizzahut.dbo.orders
select * from pizzahut.dbo.order_details

-- Retrieve the total number of orders placed.

select COUNT(pizzahut.dbo.orders.order_id) from pizzahut.dbo.orders

-- Calculate the total revenue generated from pizza sales.

select SUM (quantity * price) as total_revenue from pizzahut.dbo.order_details
full outer join pizzahut.dbo.pizzas
on pizzahut.dbo.pizzas.pizza_id = pizzahut.dbo.order_details.pizza_id

-- Identify the highest-priced pizza.

select name, price from pizzahut.dbo.pizzas
full outer join pizzahut.dbo.pizza_types
on  pizzahut.dbo.pizza_types.pizza_type_id = pizzahut.dbo.pizzas.pizza_type_id
where price = (SELECT MAX(price) FROM pizzahut.dbo.pizzas);


-- Identify the most common pizza size ordered.

select top 1 size, sum(cast (quantity as int)) as pizza_quantity from pizzahut.dbo.pizzas
join pizzahut.dbo.order_details
on pizzahut.dbo.pizzas.pizza_id = pizzahut.dbo.order_details.pizza_id
group by size
order by pizza_quantity desc

-- List the top 5 most ordered pizza types along with their quantities.

select top 5 pizza_type_id, sum(cast (quantity as int)) as pizza_quantity from pizzahut.dbo.pizzas
join pizzahut.dbo.order_details
on pizzahut.dbo.pizzas.pizza_id = pizzahut.dbo.order_details.pizza_id
group by pizza_type_id
order by pizza_quantity desc

-- Join the necessary tables to find the total quantity of each pizza category ordered.

select pizza_type_id, sum(cast (quantity as int)) as pizza_quantity from pizzahut.dbo.pizzas
join pizzahut.dbo.order_details
on pizzahut.dbo.pizzas.pizza_id = pizzahut.dbo.order_details.pizza_id
group by pizza_type_id
order by pizza_quantity desc


-- Determine the distribution of orders by hour of the day.

select DATEPART(HOUR, time) as time_hours , count(order_id) as order_counts from pizzahut.dbo.orders
group by DATEPART(HOUR, time)
order by DATEPART(HOUR, time) asc

-- Join relevant tables to find the category-wise distribution of pizzas.


select pizzahut.dbo.pizza_types.category, sum(quant.pizza_quantity) from pizzahut.dbo.pizza_types
join (

select pizza_type_id, sum(cast (quantity as int)) as pizza_quantity from pizzahut.dbo.pizzas
join pizzahut.dbo.order_details
on pizzahut.dbo.pizzas.pizza_id = pizzahut.dbo.order_details.pizza_id
group by pizza_type_id
) as quant
on pizzahut.dbo.pizza_types.pizza_type_id = quant.pizza_type_id
group by pizzahut.dbo.pizza_types.category

-- Group the orders by date and calculate the average number of pizzas ordered per day.

select date, sum(CAST (quantity as int)) from pizzahut.dbo.orders
join pizzahut.dbo.order_details
on pizzahut.dbo.orders.order_id = pizzahut.dbo.order_details.order_id
group by date
order by date asc

-- Determine the top 3 most ordered pizza types based on revenue.

select top 3 pizza_type_id, sum ((price * quantity)) as amount_generated from pizzahut.dbo.pizzas
join pizzahut.dbo.order_details
on pizzahut.dbo.order_details.pizza_id = pizzahut.dbo.pizzas.pizza_id
group by pizza_type_id
order by amount_generated desc

-- Calculate the percentage contribution of each pizza type to total revenue.

select  pizza_type_id, sum ((price * quantity)) as amount_generated, (sum ((price * quantity)* 100) / SUM(sum (price * quantity)) over()) as percent_contribution 
from pizzahut.dbo.pizzas
join pizzahut.dbo.order_details
on pizzahut.dbo.order_details.pizza_id = pizzahut.dbo.pizzas.pizza_id
group by pizza_type_id
order by amount_generated desc

-- Analyze the cumulative revenue generated over time.


select date , sum(price * quantity) as amount_generated, sum(sum(price * quantity)) over(order by date) as cummulative_revenue
from pizzahut.dbo.pizzas
join pizzahut.dbo.order_details
on pizzahut.dbo.order_details.pizza_id = pizzahut.dbo.pizzas.pizza_id 
join pizzahut.dbo.orders
on pizzahut.dbo.orders.order_id = pizzahut.dbo.order_details.order_id
group by date
order by date asc



 























