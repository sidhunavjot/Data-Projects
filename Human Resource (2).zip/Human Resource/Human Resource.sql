select * from dbo.['Human Resources$'];

--data cleaning
EXEC sp_columns "['Human Resources$']";
EXEC sp_help "['Human Resources$']";

--Analysis

-- 1. What is the gender breakdown of employees in the company?

select 
gender, count(gender) as gender_breakdown
from dbo.['Human Resources$']
group by gender
order by gender_breakdown desc

-- 2. What is the race/ethnicity breakdown of employees in the company?

select 
race, count(race) as race_breakdown
from dbo.['Human Resources$']
group by race
order by race_breakdown desc;

-- 3. What is the age distribution of employees in the company?


with age_tes as (
select
DATEDIFF(YEAR, birthdate, GETDATE()) as age
from dbo.['Human Resources$'] )

select
age, count(age) as age_count
from age_tes
group by age
order by age;

-- 4. How many employees work at headquarters versus remote locations?

select
location, count(location) as location_count
from dbo.['Human Resources$']
group by location;

-- 5. What is the average length of employment for employees who have been terminated? --->> to do later

select
hire_date, termdate,

CASE
        WHEN termdate IS NULL THEN NULL
        ELSE DATEDIFF(day, CONVERT(date, hire_date, 101), CONVERT(date, termdate, 101))
    END AS diff_hire_term_date

from dbo.['Human Resources$']


-- 6. How does the gender distribution vary across departments and job titles?

select 
department, gender , count(gender) as gender , jobtitle
from dbo.['Human Resources$']
group by department, gender, jobtitle

-- 7. What is the distribution of job titles across the company?


select 
jobtitle, count(jobtitle) as job_count
from dbo.['Human Resources$']
group by jobtitle

-- 8. Which department has the highest turnover rate?
-- datanot available in this table



-- 9. What is the distribution of employees across locations by city and state?

select 
location_state, COUNT(location_state) as people_in_state, location_city
from dbo.['Human Resources$']
group by location_state, location_city










